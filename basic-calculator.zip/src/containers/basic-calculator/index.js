import BasicCalculator from './basic-calculator';

export default BasicCalculator;