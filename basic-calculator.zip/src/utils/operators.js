export default [{
    value: '/',
    icon: 'percentage'
}, {
    value: '*',
    icon: 'times'
}, {
    value: '+',
    icon: 'plus'
}, {
    value: '-',
    icon: 'minus'
}, {
    value: '=',
    icon: 'equals'
}];