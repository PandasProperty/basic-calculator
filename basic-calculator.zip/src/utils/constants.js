export const ROLES = {
    OPERAND: 'operand',
    OPERATOR: 'operator',
    RESET: 'reset',
    INPUT: 'input'
};

export const EQUALS = '='; 