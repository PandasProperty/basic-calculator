import {
    faPlus, faMinus, faPercentage,faTimes, faEquals
} from '@fortawesome/free-solid-svg-icons';

export default {
    plus: faPlus,
    minus: faMinus,
    percentage: faPercentage,
    times: faTimes,
    equals: faEquals
}