import Cell from './cell';

export default Cell;